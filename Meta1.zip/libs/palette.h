#define BLACK		0.0, 0.0, 0.0, 1.0
#define WHITE		1.0, 1.0, 1.0, 1.0
#define RED			1.0, 0.0, 0.0, 1.0
#define GREEN		0.0, 1.0, 0.0, 1.0
#define BLUE		0.0, 0.0, 1.0, 1.0
#define LIGHTGRAY	0.4, 0.4, 0.4, 1.0
#define GRAY		0.1, 0.1, 0.1, 1.0
