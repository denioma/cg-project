#pragma once
#include <GL/freeglut.h>

void cube(const GLdouble* colors);
